import domain.AdvancedBuilder;
import domain.MidleBuilder;
import domain.ProfessionalBuilder;
import interfaces.Builder;

public class Main {

    public static void main(String[] args) {
        Builder ProfBuilder = new AdvancedBuilder(new MidleBuilder());
        ProfBuilder.modify();
        System.out.println();
        System.out.println();

        Builder advBuilder = new ProfessionalBuilder(new AdvancedBuilder(new MidleBuilder()));
        advBuilder.modify();

    }
}
