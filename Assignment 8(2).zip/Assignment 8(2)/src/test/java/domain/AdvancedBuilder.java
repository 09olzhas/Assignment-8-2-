package domain;

import interfaces.Builder;

public class AdvancedBuilder extends BuilderDecorator{

     public AdvancedBuilder(Builder builder){
         super(builder);
     }

    @Override
    public void modify() {
        super.modify();
        System.out.println("Updated to Advanced Builder");
    }
}
