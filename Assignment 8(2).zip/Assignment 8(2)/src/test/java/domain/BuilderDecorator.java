package domain;

import interfaces.Builder;

public class BuilderDecorator implements Builder {

    protected Builder builder;

    public BuilderDecorator(Builder builder) {
        setBuilder(builder);
    }

    public void setBuilder(Builder builder) {
        this.builder = builder;
    }

    public void modify() {
        this.builder.modify();
    }
}
