package domain;

import interfaces.Builder;

public class MidleBuilder implements Builder {

    public void modify() {
        System.out.println("Updated to MiddleBuilder");
    }

}
