package domain;

import interfaces.Builder;

public class ProfessionalBuilder extends BuilderDecorator {

     public ProfessionalBuilder(Builder builder) {

          super(builder);
     }

    @Override
    public void modify() {
        super.modify();
        System.out.println("Updated to Professional Builder");
    }
}
