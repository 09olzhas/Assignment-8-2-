package interfaces;

public interface Builder {

     void modify ();
}
